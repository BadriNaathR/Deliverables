import streamlit as st
import anthropic
import json
import re
from datetime import datetime

# ─── Page Config ─────────────────────────────────────────────
st.set_page_config(
    page_title="WARM – AI Code Quality Checker",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded"
)

# ─── Custom CSS ───────────────────────────────────────────────
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&family=Fira+Code&display=swap');

html, body, [class*="css"] {
    font-family: 'Plus Jakarta Sans', sans-serif;
}

/* Hide default header */
#MainMenu, header, footer { visibility: hidden; }

/* Hero banner */
.hero-banner {
    background: linear-gradient(135deg, #0f172a 0%, #1e3a5f 60%, #312e81 100%);
    border-radius: 16px;
    padding: 36px 40px;
    margin-bottom: 28px;
    position: relative;
    overflow: hidden;
}
.hero-banner::before {
    content: '🤖';
    position: absolute;
    right: 30px;
    top: 10px;
    font-size: 100px;
    opacity: 0.1;
}
.hero-title {
    color: white;
    font-size: 32px;
    font-weight: 800;
    letter-spacing: -1px;
    margin: 0 0 6px 0;
}
.hero-subtitle {
    color: #94a3b8;
    font-size: 15px;
    margin: 0 0 16px 0;
}
.hero-tag {
    display: inline-block;
    background: rgba(79,70,229,0.3);
    border: 1px solid #818cf8;
    color: #a5b4fc;
    padding: 4px 14px;
    border-radius: 20px;
    font-size: 11px;
    font-family: 'Fira Code', monospace;
    letter-spacing: 2px;
}

/* Result cards */
.result-card {
    background: white;
    border-radius: 12px;
    padding: 20px 24px;
    margin-bottom: 16px;
    border: 1.5px solid #e2e8f0;
    border-left: 4px solid #e2e8f0;
    box-shadow: 0 1px 4px rgba(0,0,0,0.05);
}
.result-card.pass { border-left-color: #059669; }
.result-card.fail { border-left-color: #dc2626; }
.result-card.warn { border-left-color: #d97706; }
.result-card.info { border-left-color: #2563eb; }

.result-header {
    display: flex;
    align-items: center;
    gap: 12px;
    margin-bottom: 8px;
}
.result-status {
    display: inline-block;
    padding: 3px 10px;
    border-radius: 12px;
    font-size: 11px;
    font-weight: 700;
    letter-spacing: 0.5px;
}
.status-pass { background: #d1fae5; color: #065f46; }
.status-fail { background: #fee2e2; color: #991b1b; }
.status-warn { background: #fef3c7; color: #92400e; }
.status-info { background: #dbeafe; color: #1e40af; }

.checklist-item { font-weight: 700; font-size: 15px; }
.observation { color: #374151; font-size: 13px; line-height: 1.6; margin-bottom: 8px; }
.suggestion { background: #f8fafc; border-left: 3px solid #2563eb; padding: 10px 14px; border-radius: 0 6px 6px 0; font-size: 13px; color: #1e40af; }

/* Score ring */
.score-container {
    text-align: center;
    padding: 24px;
    background: white;
    border-radius: 16px;
    border: 1.5px solid #e2e8f0;
    margin-bottom: 20px;
}
.score-big {
    font-size: 56px;
    font-weight: 800;
    line-height: 1;
}
.score-label { font-size: 13px; color: #64748b; margin-top: 4px; }

/* Metric */
.metric-row { display: flex; gap: 12px; flex-wrap: wrap; margin-bottom: 20px; }
.metric-box {
    flex: 1;
    min-width: 100px;
    background: white;
    border: 1.5px solid #e2e8f0;
    border-radius: 10px;
    padding: 14px;
    text-align: center;
}
.metric-val { font-size: 24px; font-weight: 800; }
.metric-lbl { font-size: 11px; color: #64748b; margin-top: 2px; }

/* Code block label */
.code-label {
    background: #1e293b;
    color: #94a3b8;
    font-family: 'Fira Code', monospace;
    font-size: 11px;
    padding: 6px 14px;
    border-radius: 6px 6px 0 0;
    margin-bottom: -8px;
}

/* Progress */
.progress-step {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 8px 0;
    font-size: 13px;
    color: #64748b;
}
.progress-step .dot {
    width: 8px; height: 8px;
    border-radius: 50%;
    background: #e2e8f0;
    flex-shrink: 0;
}
.progress-step.done .dot { background: #059669; }
.progress-step.active .dot { background: #2563eb; animation: pulse 1s infinite; }
@keyframes pulse { 0%,100%{opacity:1} 50%{opacity:0.4} }

/* Divider */
.section-divider {
    height: 1px;
    background: linear-gradient(to right, #e2e8f0, transparent);
    margin: 28px 0;
}
</style>
""", unsafe_allow_html=True)

# ─── Default Checklist ────────────────────────────────────────
DEFAULT_CHECKLIST = """1. Code Readability & Naming Conventions
2. Error Handling & Exception Management
3. Security Vulnerabilities (SQL injection, XSS, hardcoded secrets)
4. Performance & Efficiency (N+1 queries, unnecessary loops, memory leaks)
5. Code Duplication & DRY Principle
6. Input Validation & Sanitisation
7. Comments & Documentation Quality
8. Function/Method Length & Single Responsibility Principle
9. Proper Use of Data Types & Type Safety
10. Logging & Observability
11. Test Coverage & Testability
12. Dependency Management & Import Hygiene"""

DEFAULT_CODE = """// WARM – Access Request Service (Node.js/Express)
const express = require('express');
const db = require('../db');

const router = express.Router();
const SECRET = "admin123"; // admin password

router.post('/requests', async (req, res) => {
    const { userId, zoneId, justification, startDate } = req.body;
    
    // Query database
    const query = "SELECT * FROM access_requests WHERE requester_id = '" + userId + "'";
    const existing = await db.query(query);
    
    if (existing.rows.length > 50) {
        res.send("Too many requests");
        return;
    }
    
    const result = await db.query(
        "INSERT INTO access_requests (requester_id, zone_id, justification, access_start_date) VALUES ($1, $2, $3, $4) RETURNING *",
        [userId, zoneId, justification, startDate]
    );
    
    res.json(result.rows[0]);
});

router.get('/requests/:id', async (req, res) => {
    const result = await db.query("SELECT * FROM access_requests WHERE request_id = '" + req.params.id + "'");
    res.json(result.rows[0]);
});

module.exports = router;"""

# ─── Sidebar ──────────────────────────────────────────────────
with st.sidebar:
    st.markdown("""
    <div style="background:linear-gradient(135deg,#0f172a,#1e3a5f);border-radius:12px;padding:20px;margin-bottom:20px">
        <div style="background:#4f46e5;color:white;padding:5px 12px;border-radius:6px;font-size:13px;font-weight:800;display:inline-block;margin-bottom:8px">WARM</div>
        <div style="color:#94a3b8;font-size:11px;letter-spacing:1px">AI CODE QUALITY CHECKER</div>
        <div style="color:rgba(255,255,255,0.6);font-size:12px;margin-top:8px">Deliverable 09 · Powered by Claude</div>
    </div>
    """, unsafe_allow_html=True)

    st.markdown("### ⚙️ Configuration")

    language = st.selectbox(
        "Code Language",
        ["JavaScript/TypeScript", "Python", "Java", "C#", "Go", "SQL", "PHP", "Ruby", "Auto-detect"],
        index=0
    )

    analysis_depth = st.selectbox(
        "Analysis Depth",
        ["Standard", "Deep Dive", "Security Focus", "Performance Focus"],
        index=0
    )

    output_format = st.selectbox(
        "Output Format",
        ["Detailed Report", "Summary Only", "Issues List"],
        index=0
    )

    show_code_snippets = st.checkbox("Include Fix Examples", value=True)
    show_metrics = st.checkbox("Show Quality Metrics", value=True)

    st.markdown("---")
    st.markdown("### 📖 About")
    st.markdown("""
    This AI-powered tool reviews your code against a custom checklist using **Claude Sonnet 4.6**.

    **How it works:**
    1. Paste your code snippet
    2. Define or use default checklist
    3. Click Analyse
    4. Get detailed observations + suggestions

    Built with **Streamlit** + **Anthropic API**
    """)

    st.markdown("---")
    st.markdown(f"""
    <div style="font-size:11px;color:#94a3b8;font-family:'Fira Code',monospace">
    v1.0.0 · {datetime.now().strftime('%Y-%m-%d')}<br>
    Model: claude-sonnet-4-6<br>
    Framework: Streamlit
    </div>
    """, unsafe_allow_html=True)

# ─── Hero ─────────────────────────────────────────────────────
st.markdown("""
<div class="hero-banner">
    <div class="hero-tag">🤖 DELIVERABLE 09 · AI AGENT · WARM-CQC-001</div>
    <h1 class="hero-title">AI Code Quality Checker</h1>
    <p class="hero-subtitle">Automated code review powered by Claude Sonnet 4.6 — analyse code against custom checklists, get detailed observations and actionable improvement suggestions.</p>
</div>
""", unsafe_allow_html=True)

# ─── Main Layout ──────────────────────────────────────────────
col_left, col_right = st.columns([1, 1], gap="large")

with col_left:
    st.markdown("### 📝 Code Input")
    st.markdown('<div class="code-label">Paste your code snippet below</div>', unsafe_allow_html=True)
    code_input = st.text_area(
        label="code",
        value=DEFAULT_CODE,
        height=380,
        label_visibility="collapsed",
        placeholder="Paste your code here..."
    )
    char_count = len(code_input)
    line_count = len(code_input.splitlines())
    st.caption(f"📊 {line_count} lines · {char_count:,} characters")

with col_right:
    st.markdown("### ✅ Quality Checklist")
    st.markdown("*Define the criteria you want to check against — one item per line*")
    checklist_input = st.text_area(
        label="checklist",
        value=DEFAULT_CHECKLIST,
        height=380,
        label_visibility="collapsed",
        placeholder="Enter checklist items (one per line)..."
    )
    checklist_items = [l.strip() for l in checklist_input.strip().splitlines() if l.strip()]
    st.caption(f"📋 {len(checklist_items)} checklist items defined")

st.markdown('<div class="section-divider"></div>', unsafe_allow_html=True)

# ─── Analyse Button ───────────────────────────────────────────
col_btn, col_info = st.columns([1, 3])
with col_btn:
    analyse_btn = st.button(
        "🔍 Analyse Code",
        type="primary",
        use_container_width=True
    )
with col_info:
    st.info(f"📡 Using **Claude Sonnet 4.6** · Analysis depth: **{analysis_depth}** · Language: **{language}**")

# ─── Analysis Function ────────────────────────────────────────
def build_prompt(code: str, checklist: list[str], language: str, depth: str, snippets: bool) -> str:
    depth_instructions = {
        "Standard": "Provide balanced analysis covering each checklist item concisely.",
        "Deep Dive": "Provide thorough, in-depth analysis. Include line references where possible. Be exhaustive.",
        "Security Focus": "Prioritise security vulnerabilities above all else. Flag any potential attack vectors critically.",
        "Performance Focus": "Prioritise performance issues. Identify bottlenecks, inefficiencies, and scalability concerns."
    }

    snippet_instruction = (
        "For each checklist item where an issue is found, include a short corrected code snippet showing the fix."
        if snippets else
        "Do not include code snippets in your response."
    )

    checklist_text = "\n".join(f"  {item}" for item in checklist)

    return f"""You are an expert code quality reviewer. Analyse the following {language} code against each checklist item below.

CODE TO REVIEW:
```
{code}
```

QUALITY CHECKLIST:
{checklist_text}

ANALYSIS INSTRUCTIONS:
- {depth_instructions.get(depth, depth_instructions["Standard"])}
- {snippet_instruction}
- For EACH checklist item, provide:
  1. STATUS: one of PASS, FAIL, WARNING, or INFO
  2. OBSERVATION: what you found (specific, not generic)
  3. SUGGESTION: actionable improvement if status is not PASS (omit if PASS)

RESPONSE FORMAT — return ONLY valid JSON, no markdown, no extra text:
{{
  "summary": {{
    "overall_score": <integer 0-100>,
    "grade": "<A/B/C/D/F>",
    "critical_issues": <integer>,
    "warnings": <integer>,
    "passed": <integer>,
    "executive_summary": "<2-3 sentence overall assessment>"
  }},
  "results": [
    {{
      "checklist_item": "<exact checklist item text>",
      "status": "<PASS|FAIL|WARNING|INFO>",
      "observation": "<specific finding>",
      "suggestion": "<actionable fix or null if PASS>",
      "code_snippet": "<corrected code snippet or null>"
    }}
  ],
  "top_priorities": ["<top 3 most important issues to fix first>"]
}}"""


def get_status_html(status: str) -> str:
    mapping = {
        "PASS":    ("pass",  "status-pass",  "✅ PASS"),
        "FAIL":    ("fail",  "status-fail",  "❌ FAIL"),
        "WARNING": ("warn",  "status-warn",  "⚠️ WARNING"),
        "INFO":    ("info",  "status-info",  "ℹ️ INFO"),
    }
    card_cls, badge_cls, label = mapping.get(status, ("info", "status-info", status))
    return card_cls, badge_cls, label


def render_results(data: dict, show_metrics: bool, show_snippets: bool):
    summary = data.get("summary", {})
    results = data.get("results", [])
    priorities = data.get("top_priorities", [])

    # Score + Summary
    score = summary.get("overall_score", 0)
    grade = summary.get("grade", "?")
    score_color = "#059669" if score >= 80 else "#d97706" if score >= 60 else "#dc2626"

    col1, col2 = st.columns([1, 2])

    with col1:
        st.markdown(f"""
        <div class="score-container">
            <div class="score-big" style="color:{score_color}">{score}</div>
            <div style="font-size:28px;font-weight:800;color:{score_color};margin-top:4px">Grade {grade}</div>
            <div class="score-label">Overall Code Quality Score</div>
        </div>
        """, unsafe_allow_html=True)

        if show_metrics:
            passed = summary.get("passed", 0)
            critical = summary.get("critical_issues", 0)
            warnings = summary.get("warnings", 0)
            st.markdown(f"""
            <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px">
                <div style="background:#d1fae5;border-radius:8px;padding:12px;text-align:center">
                    <div style="font-size:22px;font-weight:800;color:#065f46">{passed}</div>
                    <div style="font-size:10px;color:#065f46">Passed</div>
                </div>
                <div style="background:#fef3c7;border-radius:8px;padding:12px;text-align:center">
                    <div style="font-size:22px;font-weight:800;color:#92400e">{warnings}</div>
                    <div style="font-size:10px;color:#92400e">Warnings</div>
                </div>
                <div style="background:#fee2e2;border-radius:8px;padding:12px;text-align:center">
                    <div style="font-size:22px;font-weight:800;color:#991b1b">{critical}</div>
                    <div style="font-size:10px;color:#991b1b">Critical</div>
                </div>
            </div>
            """, unsafe_allow_html=True)

    with col2:
        st.markdown("#### 📋 Executive Summary")
        st.info(summary.get("executive_summary", ""))

        if priorities:
            st.markdown("#### 🎯 Top Priorities to Fix")
            for i, p in enumerate(priorities, 1):
                st.markdown(f"**{i}.** {p}")

    st.markdown('<div class="section-divider"></div>', unsafe_allow_html=True)
    st.markdown("### 🔍 Detailed Results by Checklist Item")

    # Filter tabs
    filter_tab = st.radio(
        "Filter by status:",
        ["All", "❌ FAIL", "⚠️ WARNING", "✅ PASS", "ℹ️ INFO"],
        horizontal=True,
        label_visibility="collapsed"
    )
    filter_map = {"All": None, "❌ FAIL": "FAIL", "⚠️ WARNING": "WARNING", "✅ PASS": "PASS", "ℹ️ INFO": "INFO"}
    active_filter = filter_map[filter_tab]

    for item in results:
        status = item.get("status", "INFO")
        if active_filter and status != active_filter:
            continue

        card_cls, badge_cls, label = get_status_html(status)
        checklist_item = item.get("checklist_item", "")
        observation = item.get("observation", "")
        suggestion = item.get("suggestion")
        snippet = item.get("code_snippet")

        st.markdown(f"""
        <div class="result-card {card_cls}">
            <div class="result-header">
                <span class="result-status {badge_cls}">{label}</span>
                <span class="checklist-item">{checklist_item}</span>
            </div>
            <div class="observation">📌 {observation}</div>
            {f'<div class="suggestion">💡 <strong>Suggestion:</strong> {suggestion}</div>' if suggestion else ''}
        </div>
        """, unsafe_allow_html=True)

        if show_snippets and snippet and status != "PASS":
            with st.expander("📝 View Suggested Fix"):
                st.code(snippet, language="javascript")


# ─── Run Analysis ────────────────────────────────────────────
if analyse_btn:
    if not code_input.strip():
        st.error("⛔ Please paste some code to analyse.")
    elif not checklist_items:
        st.error("⛔ Please define at least one checklist item.")
    else:
        st.markdown('<div class="section-divider"></div>', unsafe_allow_html=True)
        st.markdown("### 🔄 Running Analysis...")

        progress_placeholder = st.empty()
        result_placeholder = st.empty()

        steps = [
            "Parsing code structure...",
            "Loading checklist criteria...",
            f"Sending to Claude Sonnet 4.6 ({language})...",
            "Processing quality analysis...",
            "Generating improvement suggestions...",
            "Compiling results..."
        ]

        progress_html = ""
        for i, step in enumerate(steps):
            progress_html += f'<div class="progress-step {"active" if i == 2 else ""}"><div class="dot"></div>{step}</div>'
        progress_placeholder.markdown(f'<div style="background:white;border:1.5px solid #e2e8f0;border-radius:12px;padding:20px">{progress_html}</div>', unsafe_allow_html=True)

        try:
            client = anthropic.Anthropic()

            prompt = build_prompt(
                code=code_input,
                checklist=checklist_items,
                language=language,
                depth=analysis_depth,
                snippets=show_code_snippets
            )

            with st.spinner("🤖 Claude is reviewing your code..."):
                message = client.messages.create(
                    model="claude-sonnet-4-6",
                    max_tokens=4096,
                    messages=[{"role": "user", "content": prompt}]
                )

            raw = message.content[0].text.strip()

            # Clean JSON
            raw = re.sub(r'^```json\s*', '', raw)
            raw = re.sub(r'\s*```$', '', raw)
            data = json.loads(raw)

            progress_html_done = ""
            for step in steps:
                progress_html_done += f'<div class="progress-step done"><div class="dot"></div>{step}</div>'
            progress_placeholder.markdown(
                f'<div style="background:white;border:1.5px solid #e2e8f0;border-radius:12px;padding:20px">{progress_html_done}</div>',
                unsafe_allow_html=True
            )

            st.success("✅ Analysis complete!")
            st.markdown('<div class="section-divider"></div>', unsafe_allow_html=True)
            st.markdown("## 📊 Quality Analysis Report")
            st.caption(f"Generated: {datetime.now().strftime('%d %b %Y at %H:%M')} · Model: claude-sonnet-4-6 · {len(checklist_items)} checklist items · {len(code_input.splitlines())} lines of code")

            render_results(data, show_metrics, show_code_snippets)

            # Export
            st.markdown('<div class="section-divider"></div>', unsafe_allow_html=True)
            col_dl1, col_dl2 = st.columns(2)
            with col_dl1:
                json_str = json.dumps(data, indent=2)
                st.download_button(
                    "⬇️ Download JSON Report",
                    data=json_str,
                    file_name=f"warm_code_quality_{datetime.now().strftime('%Y%m%d_%H%M')}.json",
                    mime="application/json",
                    use_container_width=True
                )
            with col_dl2:
                # Build text report
                lines = ["WARM Code Quality Report", "=" * 50,
                         f"Date: {datetime.now().strftime('%d %b %Y %H:%M')}",
                         f"Score: {data['summary']['overall_score']}/100 (Grade {data['summary']['grade']})",
                         f"Executive Summary: {data['summary']['executive_summary']}",
                         "", "RESULTS:", ""]
                for r in data.get("results", []):
                    lines.append(f"[{r['status']}] {r['checklist_item']}")
                    lines.append(f"  Finding: {r['observation']}")
                    if r.get("suggestion"):
                        lines.append(f"  Fix: {r['suggestion']}")
                    lines.append("")
                txt_report = "\n".join(lines)
                st.download_button(
                    "⬇️ Download Text Report",
                    data=txt_report,
                    file_name=f"warm_code_quality_{datetime.now().strftime('%Y%m%d_%H%M')}.txt",
                    mime="text/plain",
                    use_container_width=True
                )

        except json.JSONDecodeError as e:
            progress_placeholder.empty()
            st.error(f"⛔ Failed to parse AI response as JSON. Raw response:\n\n{raw[:500]}")
        except anthropic.AuthenticationError:
            progress_placeholder.empty()
            st.error("⛔ Invalid Anthropic API key. Please check your ANTHROPIC_API_KEY environment variable.")
        except Exception as e:
            progress_placeholder.empty()
            st.error(f"⛔ Analysis failed: {str(e)}")

else:
    # Welcome state
    st.markdown('<div class="section-divider"></div>', unsafe_allow_html=True)
    col1, col2, col3 = st.columns(3)
    with col1:
        st.markdown("""
        <div style="background:white;border:1.5px solid #e2e8f0;border-radius:12px;padding:24px;text-align:center">
            <div style="font-size:36px;margin-bottom:12px">📋</div>
            <div style="font-weight:700;margin-bottom:6px">Custom Checklist</div>
            <div style="font-size:13px;color:#64748b">Define your own quality criteria or use our default 12-item checklist</div>
        </div>
        """, unsafe_allow_html=True)
    with col2:
        st.markdown("""
        <div style="background:white;border:1.5px solid #e2e8f0;border-radius:12px;padding:24px;text-align:center">
            <div style="font-size:36px;margin-bottom:12px">🤖</div>
            <div style="font-weight:700;margin-bottom:6px">AI-Powered Review</div>
            <div style="font-size:13px;color:#64748b">Claude Sonnet 4.6 analyses each item individually with expert-level insight</div>
        </div>
        """, unsafe_allow_html=True)
    with col3:
        st.markdown("""
        <div style="background:white;border:1.5px solid #e2e8f0;border-radius:12px;padding:24px;text-align:center">
            <div style="font-size:36px;margin-bottom:12px">💡</div>
            <div style="font-weight:700;margin-bottom:6px">Actionable Fixes</div>
            <div style="font-size:13px;color:#64748b">Every issue comes with a specific suggestion and optional corrected code snippet</div>
        </div>
        """, unsafe_allow_html=True)

    st.markdown("""
    <div style="background:#eff6ff;border:1px solid #bfdbfe;border-radius:10px;padding:16px 20px;margin-top:20px;font-size:13px">
        💡 <strong>Getting Started:</strong> A sample WARM code snippet and default checklist have been pre-loaded above.
        Click <strong>"🔍 Analyse Code"</strong> to see the AI in action, or paste your own code and customise the checklist.
    </div>
    """, unsafe_allow_html=True)
